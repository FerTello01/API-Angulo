'use client'

import { useState, useEffect, Suspense } from 'react'
import { useSearchParams, useRouter } from 'next/navigation'
import Link from 'next/link'
import { Card } from '@/components/ui/card'
import { Button, buttonVariants } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { VerificationLevelBadge } from '@/components/impact/badges'
import { mockCertificates, mockOrganizations } from '@/lib/mock-data'
import {
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Clock,
  Search,
  ShieldCheck,
  ArrowRight,
  Building2,
} from 'lucide-react'

// ─── Result states ─────────────────────────────────────────────────────────────

type VerifyState = 'idle' | 'loading' | 'confirmed' | 'processing' | 'failed' | 'revoked' | 'not_found'

function getStateForCert(cert: (typeof mockCertificates)[number] | undefined): VerifyState {
  if (!cert) return 'not_found'
  if (cert.estado === 'activo') return 'confirmed'
  if (cert.estado === 'revocado') return 'revoked'
  if (cert.estado === 'expirado') return 'failed'
  return 'processing'
}

// ─── State result cards ────────────────────────────────────────────────────────

function ConfirmedResult({ cert }: { cert: (typeof mockCertificates)[number] }) {
  const org = mockOrganizations.find((o) => o.id === cert.organizacionId)
  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center gap-3 rounded-xl border border-[oklch(0.72_0.18_130)/40] bg-brand-lime-light px-5 py-4">
        <CheckCircle2 className="h-5 w-5 shrink-0 text-[oklch(0.38_0.12_152)]" />
        <div>
          <p className="font-semibold text-sm text-[oklch(0.28_0.1_152)]">Certificado válido y activo</p>
          <p className="text-xs text-[oklch(0.4_0.1_152)] mt-0.5">
            Verificación completada correctamente. El certificado es auténtico.
          </p>
        </div>
      </div>
      <Card className="p-6">
        <div className="flex items-start justify-between gap-4 mb-5">
          <div>
            <p className="font-mono text-xs font-semibold text-muted-foreground">{cert.numero}</p>
            <p className="font-heading text-lg font-normal text-foreground mt-0.5">
              Certificado nivel <span className="capitalize">{cert.nivel}</span>
            </p>
          </div>
          <VerificationLevelBadge level={cert.nivel} />
        </div>
        {org && (
          <div className="flex items-center gap-3 mb-5">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-muted">
              <Building2 className="h-4 w-4 text-muted-foreground" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Organización</p>
              <p className="font-medium text-sm text-foreground">{org.nombre}</p>
            </div>
          </div>
        )}
        <div className="grid grid-cols-2 gap-4 text-xs">
          <div>
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Emitido</p>
            <p className="font-medium text-foreground mt-0.5">
              {new Date(cert.emitidoEn).toLocaleDateString('es-MX', { year: 'numeric', month: 'long', day: 'numeric' })}
            </p>
          </div>
          <div>
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Expira</p>
            <p className="font-medium text-foreground mt-0.5">
              {new Date(cert.expiraEn).toLocaleDateString('es-MX', { year: 'numeric', month: 'long', day: 'numeric' })}
            </p>
          </div>
          <div>
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Validador</p>
            <p className="font-medium text-foreground mt-0.5">{cert.emisorNombre}</p>
          </div>
          <div>
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Código</p>
            <p className="font-mono font-medium text-foreground mt-0.5 text-[10px]">{cert.codigoVerificacion}</p>
          </div>
        </div>
        <div className="mt-5 pt-5 border-t border-border">
          <Link href={`/certificates/${cert.id}`} className={buttonVariants({ variant: "outline", size: "sm" })}>
            Ver certificado completo <ArrowRight className="ml-1.5 h-3.5 w-3.5" />
          </Link>
        </div>
      </Card>
    </div>
  )
}

function ProcessingResult() {
  return (
    <div className="flex items-center gap-3 rounded-xl border border-[oklch(0.48_0.14_245)/30] bg-brand-blue-light px-5 py-4">
      <Clock className="h-5 w-5 shrink-0 text-[oklch(0.48_0.14_245)]" />
      <div>
        <p className="font-semibold text-sm text-[oklch(0.28_0.12_245)]">Verificación en proceso</p>
        <p className="text-xs text-[oklch(0.38_0.12_245)] mt-0.5">
          Este certificado está siendo procesado. La verificación aún no ha sido completada.
        </p>
      </div>
    </div>
  )
}

function FailedResult() {
  return (
    <div className="flex items-center gap-3 rounded-xl border border-[oklch(0.72_0.16_65)/30] bg-brand-amber-light px-5 py-4">
      <AlertTriangle className="h-5 w-5 shrink-0 text-[oklch(0.52_0.14_65)]" />
      <div>
        <p className="font-semibold text-sm text-[oklch(0.38_0.13_65)]">Certificado expirado</p>
        <p className="text-xs text-[oklch(0.45_0.12_65)] mt-0.5">
          Este certificado existió pero ya expiró. Consulta con la organización sobre su renovación.
        </p>
      </div>
    </div>
  )
}

function RevokedResult() {
  return (
    <div className="flex items-center gap-3 rounded-xl border border-[oklch(0.57_0.22_27)/25] bg-[oklch(0.96_0.02_25)] px-5 py-4">
      <XCircle className="h-5 w-5 shrink-0 text-[oklch(0.57_0.22_27)]" />
      <div>
        <p className="font-semibold text-sm text-[oklch(0.42_0.18_27)]">Certificado revocado</p>
        <p className="text-xs text-[oklch(0.48_0.16_27)] mt-0.5">
          Este certificado fue revocado. Ya no es válido como evidencia de verificación.
        </p>
      </div>
    </div>
  )
}

function NotFoundResult() {
  return (
    <div className="flex items-center gap-3 rounded-xl border border-border bg-muted px-5 py-4">
      <XCircle className="h-5 w-5 shrink-0 text-muted-foreground" />
      <div>
        <p className="font-semibold text-sm text-foreground">Certificado no encontrado</p>
        <p className="text-xs text-muted-foreground mt-0.5">
          No existe ningún certificado con ese número o código de verificación. Verifica que el código sea correcto.
        </p>
      </div>
    </div>
  )
}

// ─── Inner component (uses useSearchParams) ────────────────────────────────────

function VerifyInner() {
  const searchParams = useSearchParams()
  const router = useRouter()
  const initialQuery = searchParams.get('cert') ?? ''
  const [query, setQuery] = useState(initialQuery)
  const [submitted, setSubmitted] = useState(initialQuery !== '')
  const [state, setState] = useState<VerifyState>('idle')
  const [result, setResult] = useState<(typeof mockCertificates)[number] | undefined>()

  function doSearch(value: string) {
    if (!value.trim()) return
    setState('loading')
    setSubmitted(true)
    // Simulate slight async delay
    setTimeout(() => {
      const cert = mockCertificates.find(
        (c) =>
          c.numero.toLowerCase() === value.trim().toLowerCase() ||
          c.codigoVerificacion.toLowerCase() === value.trim().toLowerCase() ||
          c.id.toLowerCase() === value.trim().toLowerCase(),
      )
      setResult(cert)
      setState(getStateForCert(cert))
    }, 600)
  }

  useEffect(() => {
    if (initialQuery) doSearch(initialQuery)
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    router.replace(`/verify?cert=${encodeURIComponent(query)}`)
    doSearch(query)
  }

  return (
    <div className="mx-auto max-w-2xl px-4 py-12">
      {/* Header */}
      <div className="text-center mb-10">
        <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-[oklch(0.22_0.04_155)]">
          <ShieldCheck className="h-7 w-7 text-brand-lime" />
        </div>
        <h1 className="font-heading text-3xl font-normal text-foreground md:text-4xl">
          Verificar certificado
        </h1>
        <p className="mt-2 text-base text-muted-foreground leading-relaxed max-w-md mx-auto">
          Introduce el número de certificado (ej. <span className="font-mono">IV-2024-0018</span>) o el
          código de verificación para comprobar su autenticidad.
        </p>
      </div>

      {/* Search form */}
      <form onSubmit={handleSubmit} className="flex gap-2 mb-8">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="IV-2024-0018 o código de atestación…"
            className="pl-9 font-mono text-sm"
            autoFocus
          />
        </div>
        <Button type="submit" disabled={state === 'loading' || !query.trim()}>
          {state === 'loading' ? (
            <span className="flex items-center gap-2">
              <Clock className="h-4 w-4 animate-spin" />
              Buscando…
            </span>
          ) : (
            'Verificar'
          )}
        </Button>
      </form>

      {/* Result */}
      {submitted && state !== 'loading' && state !== 'idle' && (
        <div className="animate-in fade-in slide-in-from-bottom-2 duration-300">
          {state === 'confirmed' && result && <ConfirmedResult cert={result} />}
          {state === 'processing' && <ProcessingResult />}
          {state === 'failed' && <FailedResult />}
          {state === 'revoked' && <RevokedResult />}
          {state === 'not_found' && <NotFoundResult />}
        </div>
      )}

      {/* Example codes */}
      {!submitted && (
        <div className="mt-6 rounded-xl border border-dashed border-border bg-muted/40 p-5">
          <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">
            Certificados de ejemplo
          </p>
          <div className="flex flex-col gap-2">
            {mockCertificates.map((c) => {
              const o = mockOrganizations.find((org) => org.id === c.organizacionId)
              return (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => {
                    setQuery(c.numero)
                    doSearch(c.numero)
                  }}
                  className="flex items-center justify-between rounded-lg border border-border bg-card px-4 py-2.5 text-left hover:border-primary/40 hover:bg-muted transition-colors group"
                >
                  <div>
                    <p className="font-mono text-xs font-semibold text-muted-foreground">{c.numero}</p>
                    <p className="text-sm font-medium text-foreground">{o?.nombre}</p>
                  </div>
                  <VerificationLevelBadge level={c.nivel} size="sm" />
                </button>
              )
            })}
          </div>
        </div>
      )}
    </div>
  )
}

// ─── Page ──────────────────────────────────────────────────────────────────────

export default function VerifyPage() {
  return (
    <Suspense fallback={
      <div className="mx-auto max-w-2xl px-4 py-12 flex justify-center">
        <Clock className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    }>
      <VerifyInner />
    </Suspense>
  )
}
