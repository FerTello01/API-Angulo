import { notFound } from 'next/navigation'
import Link from 'next/link'
import { Card } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { VerificationLevelBadge } from '@/components/impact/badges'
import { MetricTypeBadge } from '@/components/impact/badges'
import {
  mockCertificates,
  mockAttestations,
  mockOrganizations,
  mockProjects,
  mockMetrics,
  mockValidators,
  mockMethodologies,
  mockEvidences,
} from '@/lib/mock-data'
import {
  ShieldCheck,
  Building2,
  CalendarDays,
  User,
  ArrowRight,
  ExternalLink,
  FileText,
  Lock,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  FileSearch,
} from 'lucide-react'

// ─── Cert status display ───────────────────────────────────────────────────────

const certStatusConfig: Record<
  string,
  { icon: React.ElementType; label: string; className: string }
> = {
  activo: {
    icon: CheckCircle2,
    label: 'Certificado activo y válido',
    className: 'bg-brand-lime-light text-[oklch(0.28_0.1_152)] border border-[oklch(0.72_0.18_130)/30]',
  },
  expirado: {
    icon: AlertTriangle,
    label: 'Certificado expirado',
    className: 'bg-brand-amber-light text-[oklch(0.38_0.13_65)] border border-[oklch(0.72_0.16_65)/30]',
  },
  revocado: {
    icon: XCircle,
    label: 'Certificado revocado',
    className: 'bg-[oklch(0.96_0.02_25)] text-[oklch(0.42_0.18_27)] border border-[oklch(0.57_0.22_27)/25]',
  },
}

// ─── Page ──────────────────────────────────────────────────────────────────────

export default async function CertificatePage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  const cert = mockCertificates.find((c) => c.id === id)
  if (!cert) notFound()

  const org = mockOrganizations.find((o) => o.id === cert.organizacionId)
  const project = cert.proyectoId ? mockProjects.find((p) => p.id === cert.proyectoId) : null
  const validator = mockValidators.find((v) => v.id === cert.emisorId)
  const attestations = mockAttestations.filter((a) => a.certificadoId === cert.id)
  const includedMetrics = mockMetrics.filter((m) => cert.metricasIncluidas.includes(m.id))
  const evidences = mockEvidences.filter((e) =>
    project ? e.proyectoId === project.id : false
  )

  const statusConf = certStatusConfig[cert.estado] ?? certStatusConfig.activo
  const StatusIcon = statusConf.icon

  return (
    <div className="mx-auto max-w-4xl px-4 py-10">
      {/* Status banner */}
      <div className={`flex items-center gap-3 rounded-xl border px-5 py-4 mb-8 ${statusConf.className}`}>
        <StatusIcon className="h-5 w-5 shrink-0" />
        <div className="flex-1">
          <p className="font-semibold text-sm">{statusConf.label}</p>
          <p className="text-xs opacity-80 mt-0.5">
            Este certificado fue emitido el{' '}
            {new Date(cert.emitidoEn).toLocaleDateString('es-MX', { year: 'numeric', month: 'long', day: 'numeric' })}
            {' '}y expira el{' '}
            {new Date(cert.expiraEn).toLocaleDateString('es-MX', { year: 'numeric', month: 'long', day: 'numeric' })}.
          </p>
        </div>
        <Link href={`/verify?cert=${cert.numero}`} className="flex items-center gap-1 text-xs font-medium hover:underline shrink-0">
          <FileSearch className="h-3.5 w-3.5" />
          Verificar
        </Link>
      </div>

      {/* ── Main certificate card ─────────────────────────────────────── */}
      <Card className="overflow-hidden p-0 mb-6">
        {/* Header band */}
        <div className="bg-[oklch(0.22_0.04_155)] px-8 py-6">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-brand-lime/20">
                <ShieldCheck className="h-6 w-6 text-brand-lime" />
              </div>
              <div>
                <p className="text-[oklch(0.75_0.025_150)] text-xs font-medium uppercase tracking-wider">Certificado de Impacto Verificado</p>
                <p className="font-mono text-sm font-semibold text-[oklch(0.95_0.01_150)] mt-0.5">{cert.numero}</p>
              </div>
            </div>
            <VerificationLevelBadge level={cert.nivel} />
          </div>
        </div>

        {/* Body */}
        <div className="p-8">
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
            {/* Organization */}
            <div>
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1.5">Organización</p>
              {org ? (
                <Link href={`/organizations/${org.slug}`} className="flex items-start gap-3 group">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-muted">
                    <Building2 className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div>
                    <p className="font-semibold text-foreground group-hover:text-primary transition-colors">{org.nombre}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{org.ciudad}, {org.pais}</p>
                  </div>
                </Link>
              ) : <p className="text-sm text-muted-foreground">—</p>}
            </div>

            {/* Project */}
            <div>
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1.5">Proyecto</p>
              {project ? (
                <Link href={`/projects/${project.id}`} className="flex items-start gap-3 group">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-muted">
                    <FileText className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div>
                    <p className="font-semibold text-foreground group-hover:text-primary transition-colors">{project.nombre}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{project.ciudad}</p>
                  </div>
                </Link>
              ) : <p className="text-sm text-muted-foreground">—</p>}
            </div>

            {/* Period */}
            <div>
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1.5">Periodo cubierto</p>
              {attestations.length > 0 ? (
                <div className="flex items-center gap-1.5 text-sm text-foreground">
                  <CalendarDays className="h-3.5 w-3.5 text-muted-foreground" />
                  {new Date(attestations[0].periodoInicio).toLocaleDateString('es-MX', { year: 'numeric', month: 'short' })}
                  {' — '}
                  {new Date(attestations[0].periodoFin).toLocaleDateString('es-MX', { year: 'numeric', month: 'short' })}
                </div>
              ) : <p className="text-sm text-muted-foreground">—</p>}
            </div>

            {/* Validator */}
            <div>
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1.5">Validador emisor</p>
              {validator ? (
                <div className="flex items-center gap-2">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[oklch(0.22_0.04_155)]">
                    <span className="text-xs font-semibold text-[oklch(0.85_0.06_150)]">
                      {validator.nombre[0]}{validator.apellido[0]}
                    </span>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-foreground">{validator.nombre} {validator.apellido}</p>
                    <p className="text-xs text-muted-foreground">{validator.organizacion}</p>
                  </div>
                </div>
              ) : <p className="text-sm text-muted-foreground">—</p>}
            </div>
          </div>

          <Separator className="my-6" />

          {/* Impact results */}
          <div>
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground mb-4">Resultados de impacto certificados</p>
            <div className="flex flex-col gap-3">
              {includedMetrics.map((metric) => {
                const att = attestations.find((a) => a.metricaId === metric.id)
                const meth = mockMethodologies.find((m) => m.id === metric.metodologiaId)
                return (
                  <div key={metric.id} className="flex items-center justify-between gap-4 rounded-lg border border-border bg-muted/40 px-4 py-3">
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      <MetricTypeBadge type={metric.tipo} size="sm" />
                      <div className="min-w-0">
                        <p className="font-medium text-sm text-foreground truncate">{metric.nombre}</p>
                        {meth && <p className="text-[10px] text-muted-foreground">{meth.nombre}</p>}
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="font-heading text-lg font-normal text-foreground">
                        {att ? att.valor.toLocaleString('es-MX') : metric.valorActual.toLocaleString('es-MX')}
                      </p>
                      <p className="text-[10px] text-muted-foreground">{metric.unidad}</p>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      </Card>

      {/* ── Public evidence ───────────────────────────────────────────── */}
      {evidences.length > 0 && (
        <section className="mb-6">
          <h2 className="font-heading text-xl font-normal text-foreground mb-4">Evidencia pública</h2>
          <div className="flex flex-col gap-3">
            {evidences.filter((e) => e.estado === 'verificado').map((ev) => (
              <Card key={ev.id} className="flex items-center gap-4 p-4">
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-muted">
                  <FileText className="h-4 w-4 text-muted-foreground" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm text-foreground truncate">{ev.titulo}</p>
                  <p className="text-xs text-muted-foreground font-mono mt-0.5">{ev.archivoNombre}</p>
                </div>
                <p className="text-xs text-muted-foreground shrink-0">
                  {new Date(ev.subidaEn).toLocaleDateString('es-MX')}
                </p>
              </Card>
            ))}
          </div>
        </section>
      )}

      {/* ── Technical attestation section ────────────────────────────── */}
      <Card className="p-6 mb-6 border-border">
        <div className="flex items-center gap-2 mb-4">
          <Lock className="h-4 w-4 text-muted-foreground" />
          <h2 className="font-heading text-lg font-normal text-foreground">Sección técnica de atestación</h2>
        </div>
        <div className="rounded-lg bg-muted/60 p-4 font-mono text-xs text-muted-foreground space-y-1">
          <p><span className="text-foreground font-medium">Certificado ID:</span> {cert.id}</p>
          <p><span className="text-foreground font-medium">Número:</span> {cert.numero}</p>
          <p><span className="text-foreground font-medium">Código de verificación:</span> {cert.codigoVerificacion}</p>
          {attestations.map((att) => (
            <div key={att.id} className="mt-2 pt-2 border-t border-border">
              <p><span className="text-foreground font-medium">Atestación ID:</span> {att.id}</p>
              <p><span className="text-foreground font-medium">Firmada el:</span> {new Date(att.firmadaEn).toISOString()}</p>
              <p><span className="text-foreground font-medium">Válida:</span> {att.valida ? 'Sí' : 'No'}</p>
              {att.notas && <p><span className="text-foreground font-medium">Notas:</span> {att.notas}</p>}
            </div>
          ))}
        </div>
      </Card>

      {/* ── Integrity disclaimer ─────────────────────────────────────── */}
      <Card className="p-5 border-border bg-muted/30">
        <div className="flex items-start gap-3">
          <AlertTriangle className="h-4 w-4 shrink-0 text-muted-foreground mt-0.5" />
          <div>
            <p className="font-semibold text-sm text-foreground">Aviso de integridad</p>
            <p className="mt-1 text-xs text-muted-foreground leading-relaxed">
              Este certificado es un documento de verificación independiente emitido por ImpactVerify con base en la
              revisión de evidencia documental y metodológica. No constituye un título-valor ni garantiza resultados
              futuros. La veracidad de los datos declarados es responsabilidad de la organización certificada.
              Los registros de atestación técnicos son conservados por ImpactVerify con fines de auditoría.
            </p>
          </div>
        </div>
      </Card>
    </div>
  )
}
