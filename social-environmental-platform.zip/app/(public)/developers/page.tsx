'use client'

import Link from 'next/link'
import { useState } from 'react'
import { cn } from '@/lib/utils'
import { buttonVariants } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import {
  ShieldCheck,
  Key,
  Code2,
  ArrowRight,
  Copy,
  CheckCheck,
  Zap,
  Globe,
  FileText,
  Lock,
  AlertCircle,
  BookOpen,
  Terminal,
  Webhook,
  BarChart3,
} from 'lucide-react'

// ─── Types ────────────────────────────────────────────────────────────────────

type HttpMethod = 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH'

interface Endpoint {
  method: HttpMethod
  path: string
  description: string
  request?: string
  response: string
  notes?: string
}

// ─── Code copy button ─────────────────────────────────────────────────────────

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false)
  const handleCopy = () => {
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }
  return (
    <button
      onClick={handleCopy}
      className="absolute right-3 top-3 flex items-center gap-1.5 rounded-md bg-[oklch(0.28_0.03_155)] px-2.5 py-1 text-xs text-[oklch(0.75_0.04_155)] transition-colors hover:bg-[oklch(0.34_0.05_155)] hover:text-[oklch(0.9_0.02_150)]"
      aria-label="Copiar código"
    >
      {copied ? <CheckCheck className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
      {copied ? 'Copiado' : 'Copiar'}
    </button>
  )
}

function CodeBlock({ code, lang = 'bash' }: { code: string; lang?: string }) {
  return (
    <div className="relative mt-3 rounded-xl bg-[oklch(0.18_0.03_155)] text-[oklch(0.88_0.03_150)]">
      <CopyButton text={code} />
      <pre className="overflow-x-auto p-4 pt-10 text-xs leading-relaxed font-mono">{code}</pre>
    </div>
  )
}

// ─── Method badge ──────────────────────────────────────────────────────────────

const methodColors: Record<HttpMethod, string> = {
  GET: 'bg-brand-blue-light text-[oklch(0.38_0.14_245)] border border-[oklch(0.48_0.14_245)/25]',
  POST: 'bg-brand-lime-light text-[oklch(0.28_0.1_152)] border border-[oklch(0.72_0.18_130)/25]',
  PUT: 'bg-brand-amber-light text-[oklch(0.38_0.13_65)] border border-[oklch(0.72_0.16_65)/25]',
  PATCH: 'bg-brand-amber-light text-[oklch(0.38_0.13_65)] border border-[oklch(0.72_0.16_65)/25]',
  DELETE: 'bg-[oklch(0.95_0.02_25)] text-[oklch(0.45_0.18_25)] border border-[oklch(0.62_0.2_25)/20]',
}

function MethodBadge({ method }: { method: HttpMethod }) {
  return (
    <span className={cn('inline-block rounded-md px-2.5 py-0.5 text-xs font-mono font-semibold', methodColors[method])}>
      {method}
    </span>
  )
}

// ─── Section anchor ────────────────────────────────────────────────────────────

function SectionTitle({ id, children }: { id: string; children: React.ReactNode }) {
  return (
    <h2 id={id} className="scroll-mt-20 font-heading text-2xl font-normal text-foreground md:text-3xl text-balance">
      {children}
    </h2>
  )
}

// ─── Endpoint card ─────────────────────────────────────────────────────────────

function EndpointCard({ endpoint }: { endpoint: Endpoint }) {
  const [open, setOpen] = useState(false)
  return (
    <Card className="overflow-hidden p-0">
      <button
        onClick={() => setOpen(!open)}
        className="flex w-full items-center gap-3 p-4 text-left transition-colors hover:bg-muted/40"
      >
        <MethodBadge method={endpoint.method} />
        <code className="flex-1 text-sm font-mono text-foreground">{endpoint.path}</code>
        <span className="hidden text-xs text-muted-foreground sm:block">{endpoint.description}</span>
        <ArrowRight className={cn('h-4 w-4 text-muted-foreground transition-transform', open && 'rotate-90')} />
      </button>
      {open && (
        <div className="border-t border-border bg-muted/20 px-4 pb-5 pt-4 space-y-4">
          <p className="text-sm text-muted-foreground">{endpoint.description}</p>
          {endpoint.request && (
            <div>
              <p className="mb-1 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Body / Params</p>
              <CodeBlock code={endpoint.request} lang="json" />
            </div>
          )}
          <div>
            <p className="mb-1 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Respuesta 200</p>
            <CodeBlock code={endpoint.response} lang="json" />
          </div>
          {endpoint.notes && (
            <div className="flex items-start gap-2 rounded-lg bg-brand-amber-light px-3 py-2.5">
              <AlertCircle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[oklch(0.55_0.16_65)]" />
              <p className="text-xs text-[oklch(0.38_0.13_65)]">{endpoint.notes}</p>
            </div>
          )}
        </div>
      )}
    </Card>
  )
}

// ─── Data ──────────────────────────────────────────────────────────────────────

const certEndpoints: Endpoint[] = [
  {
    method: 'POST',
    path: '/v1/certificates',
    description: 'Emite un certificado de impacto para un cliente de tu empresa.',
    request: JSON.stringify(
      {
        client_id: 'cli_8f3kx92p',
        project_id: 'proj_4a1bz',
        period_start: '2024-01-01',
        period_end: '2024-12-31',
        metrics: [
          { key: 'co2_toneladas', value: 420, unit: 'tCO₂e', verified: true },
          { key: 'arboles_plantados', value: 1800, unit: 'árboles', verified: true },
        ],
        evidence_ids: ['ev_001', 'ev_002'],
        level: 'oro',
        notes: 'Verificado por auditor externo en feb-2025.',
      },
      null,
      2,
    ),
    response: JSON.stringify(
      {
        id: 'cert_7xq2m',
        number: 'PRF-2025-0041',
        status: 'active',
        client_id: 'cli_8f3kx92p',
        issued_at: '2025-07-12T14:32:00Z',
        level: 'oro',
        public_url: 'https://proofact.io/certificates/cert_7xq2m',
        qr_url: 'https://proofact.io/qr/cert_7xq2m.png',
        share_embed:
          '<iframe src="https://proofact.io/embed/cert_7xq2m" width="480" height="280"></iframe>',
      },
      null,
      2,
    ),
    notes:
      'El campo level puede ser bronce | plata | oro | platino. Proofact valida que los evidence_ids pertenezcan al proyecto.',
  },
  {
    method: 'GET',
    path: '/v1/certificates/:id',
    description: 'Consulta los detalles de un certificado emitido.',
    response: JSON.stringify(
      {
        id: 'cert_7xq2m',
        number: 'PRF-2025-0041',
        status: 'active',
        level: 'oro',
        client_id: 'cli_8f3kx92p',
        project_id: 'proj_4a1bz',
        issued_at: '2025-07-12T14:32:00Z',
        expires_at: '2026-07-12T14:32:00Z',
        validator: { name: 'Dra. Ana Reyes', org: 'Ecosustenta A.C.' },
        metrics: [
          { key: 'co2_toneladas', value: 420, unit: 'tCO₂e' },
          { key: 'arboles_plantados', value: 1800, unit: 'árboles' },
        ],
        public_url: 'https://proofact.io/certificates/cert_7xq2m',
      },
      null,
      2,
    ),
  },
  {
    method: 'GET',
    path: '/v1/certificates',
    description: 'Lista todos los certificados emitidos bajo tu cuenta de empresa.',
    response: JSON.stringify(
      {
        data: [{ id: 'cert_7xq2m', number: 'PRF-2025-0041', status: 'active', level: 'oro' }],
        pagination: { page: 1, per_page: 20, total: 41 },
      },
      null,
      2,
    ),
  },
  {
    method: 'PATCH',
    path: '/v1/certificates/:id/revoke',
    description: 'Revoca un certificado activo. La acción es irreversible.',
    request: JSON.stringify({ reason: 'Datos de proyecto actualizados tras auditoría.' }, null, 2),
    response: JSON.stringify({ id: 'cert_7xq2m', status: 'revoked', revoked_at: '2025-07-12T16:00:00Z' }, null, 2),
    notes: 'El certificado revocado sigue siendo visible públicamente con estado "revocado" para mantener trazabilidad.',
  },
]

const clientEndpoints: Endpoint[] = [
  {
    method: 'POST',
    path: '/v1/clients',
    description: 'Registra un cliente en tu cuenta para poder emitirle certificados.',
    request: JSON.stringify(
      {
        name: 'Bosques Vivos S.A. de C.V.',
        email: 'contacto@bosquesvivos.mx',
        external_id: 'erp-client-00421',
        metadata: { sector: 'silvicultura', region: 'Oaxaca' },
      },
      null,
      2,
    ),
    response: JSON.stringify(
      { id: 'cli_8f3kx92p', name: 'Bosques Vivos S.A. de C.V.', email: 'contacto@bosquesvivos.mx', created_at: '2025-07-01T09:00:00Z' },
      null,
      2,
    ),
  },
  {
    method: 'GET',
    path: '/v1/clients/:id/certificates',
    description: 'Lista todos los certificados emitidos para un cliente específico.',
    response: JSON.stringify(
      {
        client_id: 'cli_8f3kx92p',
        data: [
          { id: 'cert_7xq2m', number: 'PRF-2025-0041', level: 'oro', status: 'active', issued_at: '2025-07-12T14:32:00Z' },
        ],
        total: 1,
      },
      null,
      2,
    ),
  },
]

const evidenceEndpoints: Endpoint[] = [
  {
    method: 'POST',
    path: '/v1/evidence',
    description: 'Sube un documento de evidencia (PDF, CSV, imagen). Retorna un ID para incluir en certificados.',
    request: `# multipart/form-data
file=@reporte_campo_2024.pdf
project_id=proj_4a1bz
type=field_report          # field_report | audit | photo | dataset | other
description="Reporte de monitoreo de carbono Q4 2024"`,
    response: JSON.stringify(
      {
        id: 'ev_001',
        filename: 'reporte_campo_2024.pdf',
        type: 'field_report',
        size_bytes: 204800,
        hash_sha256: 'a3f8...c291',
        uploaded_at: '2025-07-11T10:00:00Z',
        project_id: 'proj_4a1bz',
      },
      null,
      2,
    ),
    notes: 'Tamaño máximo: 50 MB por archivo. Formatos permitidos: PDF, CSV, XLSX, PNG, JPG, GeoJSON.',
  },
]

const webhookEvents = [
  { event: 'certificate.issued', desc: 'Se emitió un nuevo certificado.' },
  { event: 'certificate.revoked', desc: 'Un certificado fue revocado.' },
  { event: 'validation.requested', desc: 'Se envió una solicitud a un validador.' },
  { event: 'validation.completed', desc: 'Un validador aprobó o rechazó la solicitud.' },
  { event: 'client.created', desc: 'Nuevo cliente registrado en tu cuenta.' },
]

// ─── Sidebar links ─────────────────────────────────────────────────────────────

const sideLinks = [
  { id: 'quickstart', label: 'Inicio rápido', icon: Zap },
  { id: 'auth', label: 'Autenticación', icon: Lock },
  { id: 'certificates', label: 'Certificados', icon: ShieldCheck },
  { id: 'clients', label: 'Clientes', icon: Globe },
  { id: 'evidence', label: 'Evidencia', icon: FileText },
  { id: 'webhooks', label: 'Webhooks', icon: Webhook },
  { id: 'errors', label: 'Códigos de error', icon: AlertCircle },
  { id: 'sdks', label: 'SDKs', icon: Code2 },
]

// ─── Page ──────────────────────────────────────────────────────────────────────

export default function DevelopersPage() {
  const [activeSection, setActiveSection] = useState('quickstart')

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="relative overflow-hidden bg-[oklch(0.18_0.03_155)] text-[oklch(0.95_0.01_150)]">
        <div className="mx-auto max-w-6xl px-4 py-16 md:py-20">
          <div className="flex items-center gap-2 mb-5">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-brand-lime/20">
              <Terminal className="h-3.5 w-3.5 text-brand-lime" />
            </div>
            <span className="text-xs font-mono font-semibold text-brand-lime tracking-widest uppercase">
              API Reference
            </span>
          </div>
          <h1 className="font-heading text-4xl font-normal leading-tight text-balance md:text-5xl">
            Certifica el impacto de tus clientes<br className="hidden md:block" /> desde tu propia plataforma
          </h1>
          <p className="mt-4 text-base leading-relaxed text-[oklch(0.72_0.025_150)] max-w-2xl">
            La API REST de Proofact te permite emitir, consultar y compartir certificados de impacto verificados a nombre de tus clientes, directamente desde tu producto. Sin procesos manuales, sin hojas de Excel.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link
              href="#quickstart"
              className={cn(
                buttonVariants({ size: 'lg' }),
                'bg-brand-lime text-[oklch(0.15_0.04_155)] hover:bg-[oklch(0.66_0.17_130)] font-semibold',
              )}
            >
              Empezar ahora <ArrowRight className="ml-1.5 h-4 w-4" />
            </Link>
            <Link
              href="/register"
              className={cn(
                buttonVariants({ variant: 'outline', size: 'lg' }),
                'border-[oklch(0.38_0.12_152)/50] text-[oklch(0.88_0.02_150)] bg-transparent hover:bg-[oklch(0.28_0.05_155)]',
              )}
            >
              <Key className="mr-1.5 h-4 w-4" />
              Obtener API Key
            </Link>
          </div>
          {/* Stat pills */}
          <div className="mt-10 flex flex-wrap gap-3">
            {[
              { icon: BarChart3, label: '3 líneas para emitir un certificado' },
              { icon: Globe, label: 'URLs públicas y embeds incluidos' },
              { icon: Webhook, label: 'Webhooks en tiempo real' },
              { icon: BookOpen, label: 'SDK para Node.js y Python' },
            ].map((f) => (
              <div key={f.label} className="flex items-center gap-2 rounded-full border border-[oklch(0.35_0.07_155)] bg-[oklch(0.24_0.04_155)] px-3 py-1.5">
                <f.icon className="h-3.5 w-3.5 text-brand-lime" />
                <span className="text-xs text-[oklch(0.78_0.04_150)]">{f.label}</span>
              </div>
            ))}
          </div>
        </div>
        {/* subtle grid bg */}
        <div className="pointer-events-none absolute inset-0 opacity-5 [background-image:linear-gradient(oklch(0.95_0.01_150)_1px,transparent_1px),linear-gradient(90deg,oklch(0.95_0.01_150)_1px,transparent_1px)] [background-size:48px_48px]" />
      </section>

      {/* Base URL banner */}
      <div className="border-b border-border bg-muted/40">
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3">
          <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Base URL</span>
          <code className="rounded-md bg-card px-3 py-1 font-mono text-sm text-foreground border border-border">
            https://api.proofact.io
          </code>
          <Badge variant="secondary" className="text-xs">v1</Badge>
          <Badge className="bg-brand-lime-light text-[oklch(0.28_0.1_152)] hover:bg-brand-lime-light text-xs">REST · JSON</Badge>
        </div>
      </div>

      {/* Main layout */}
      <div className="mx-auto max-w-6xl px-4 py-12">
        <div className="flex gap-10">
          {/* Sticky sidebar */}
          <aside className="hidden w-52 shrink-0 lg:block">
            <div className="sticky top-24 space-y-0.5">
              <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground px-2">Contenidos</p>
              {sideLinks.map((l) => (
                <a
                  key={l.id}
                  href={`#${l.id}`}
                  onClick={() => setActiveSection(l.id)}
                  className={cn(
                    'flex items-center gap-2 rounded-md px-2 py-1.5 text-sm transition-colors',
                    activeSection === l.id
                      ? 'bg-accent text-accent-foreground font-medium'
                      : 'text-muted-foreground hover:text-foreground hover:bg-muted',
                  )}
                >
                  <l.icon className="h-3.5 w-3.5 shrink-0" />
                  {l.label}
                </a>
              ))}
            </div>
          </aside>

          {/* Content */}
          <main className="min-w-0 flex-1 space-y-16">

            {/* ── Quickstart ─────────────────────────────────────────────── */}
            <section id="quickstart">
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1">01</p>
              <SectionTitle id="quickstart-title">Inicio rápido — tu primer certificado en 5 minutos</SectionTitle>
              <p className="mt-3 text-sm text-muted-foreground leading-relaxed max-w-2xl">
                El flujo completo para certificar el impacto de un cliente tiene tres pasos: registrar al cliente, subir la evidencia del proyecto y emitir el certificado. Proofact te devuelve una URL pública y un embed listo para incrustar.
              </p>

              <div className="mt-6 space-y-3">
                <div className="flex items-center gap-2">
                  <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-brand-lime-light text-[oklch(0.28_0.1_152)] text-xs font-bold">1</span>
                  <p className="text-sm font-semibold text-foreground">Instala el SDK</p>
                </div>
                <CodeBlock code={`npm install @proofact/node`} />

                <div className="mt-5 flex items-center gap-2">
                  <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-brand-lime-light text-[oklch(0.28_0.1_152)] text-xs font-bold">2</span>
                  <p className="text-sm font-semibold text-foreground">Registra al cliente y emite el certificado</p>
                </div>
                <CodeBlock
                  lang="typescript"
                  code={`import { Proofact } from '@proofact/node'

const pf = new Proofact({ apiKey: process.env.PROOFACT_API_KEY })

// 1. Registrar cliente
const client = await pf.clients.create({
  name: 'Bosques Vivos S.A. de C.V.',
  email: 'contacto@bosquesvivos.mx',
  external_id: 'erp-00421',          // tu ID interno, opcional
})

// 2. Subir evidencia
const evidence = await pf.evidence.upload({
  file: fs.createReadStream('./reporte_monitoreo_q4.pdf'),
  project_id: 'proj_4a1bz',
  type: 'field_report',
  description: 'Reporte de monitoreo de carbono Q4 2024',
})

// 3. Emitir certificado
const cert = await pf.certificates.issue({
  client_id: client.id,
  project_id: 'proj_4a1bz',
  period_start: '2024-01-01',
  period_end:   '2024-12-31',
  level: 'oro',
  metrics: [
    { key: 'co2_toneladas',    value: 420,  unit: 'tCO₂e'    },
    { key: 'arboles_plantados', value: 1800, unit: 'árboles' },
  ],
  evidence_ids: [evidence.id],
})

console.log(cert.public_url)  // https://proofact.io/certificates/cert_7xq2m
console.log(cert.qr_url)      // PNG descargable para facturas / reportes
`}
                />

                <div className="mt-5 flex items-center gap-2">
                  <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-brand-lime-light text-[oklch(0.28_0.1_152)] text-xs font-bold">3</span>
                  <p className="text-sm font-semibold text-foreground">Incrusta el sello en tu producto</p>
                </div>
                <CodeBlock
                  lang="html"
                  code={`<!-- Pega este iframe donde quieras mostrar el certificado -->
<iframe
  src="https://proofact.io/embed/cert_7xq2m"
  width="480"
  height="280"
  frameborder="0"
  allow="clipboard-write"
  loading="lazy"
  title="Certificado de impacto Proofact">
</iframe>`}
                />
              </div>
            </section>

            <Separator />

            {/* ── Auth ───────────────────────────────────────────────────── */}
            <section id="auth">
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1">02</p>
              <SectionTitle id="auth-title">Autenticación</SectionTitle>
              <p className="mt-3 text-sm text-muted-foreground leading-relaxed max-w-2xl">
                Todas las solicitudes deben incluir tu API Key en el header <code className="rounded bg-muted px-1.5 py-0.5 font-mono text-xs">Authorization</code>. Genera una clave desde el panel de empresa en <strong>Configuración → API Keys</strong>.
              </p>

              <div className="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-3">
                {[
                  { label: 'prf_live_...', desc: 'Clave de producción. Emite certificados reales.', color: 'bg-brand-lime-light text-[oklch(0.28_0.1_152)]' },
                  { label: 'prf_test_...', desc: 'Clave de sandbox. Sin costo, sin certificados reales.', color: 'bg-brand-blue-light text-[oklch(0.28_0.12_245)]' },
                  { label: 'prf_ro_...', desc: 'Solo lectura. Para consultas públicas o dashboards.', color: 'bg-brand-amber-light text-[oklch(0.38_0.13_65)]' },
                ].map((k) => (
                  <div key={k.label} className={cn('rounded-xl border border-border p-4', k.color)}>
                    <code className="text-xs font-mono font-semibold">{k.label}</code>
                    <p className="mt-1.5 text-xs leading-relaxed opacity-80">{k.desc}</p>
                  </div>
                ))}
              </div>

              <CodeBlock
                code={`curl https://api.proofact.io/v1/certificates \\
  -H "Authorization: Bearer prf_live_tu_api_key_aqui" \\
  -H "Content-Type: application/json"`}
              />

              <div className="mt-4 flex items-start gap-2 rounded-lg border border-border bg-card p-3.5">
                <Lock className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />
                <p className="text-xs text-muted-foreground leading-relaxed">
                  Nunca expongas tu API Key en el frontend. Todas las solicitudes que emiten o modifican certificados deben originarse desde tu servidor.
                </p>
              </div>
            </section>

            <Separator />

            {/* ── Certificates ───────────────────────────────────────────── */}
            <section id="certificates">
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1">03</p>
              <SectionTitle id="certs-title">Certificados</SectionTitle>
              <p className="mt-3 mb-5 text-sm text-muted-foreground leading-relaxed max-w-2xl">
                El recurso central de la API. Cada certificado tiene una URL pública permanente, un código QR y un embed HTML que puedes entregar directamente a tu cliente como prueba verificada de su impacto.
              </p>
              <div className="space-y-3">
                {certEndpoints.map((ep) => (
                  <EndpointCard key={ep.path + ep.method} endpoint={ep} />
                ))}
              </div>
            </section>

            <Separator />

            {/* ── Clients ────────────────────────────────────────────────── */}
            <section id="clients">
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1">04</p>
              <SectionTitle id="clients-title">Clientes</SectionTitle>
              <p className="mt-3 mb-5 text-sm text-muted-foreground leading-relaxed max-w-2xl">
                Un cliente es la empresa o persona a quien le emites certificados. Puedes vincular tu ID interno (ERP, CRM) a través del campo <code className="rounded bg-muted px-1.5 py-0.5 font-mono text-xs">external_id</code> para no duplicar registros.
              </p>
              <div className="space-y-3">
                {clientEndpoints.map((ep) => (
                  <EndpointCard key={ep.path + ep.method} endpoint={ep} />
                ))}
              </div>
            </section>

            <Separator />

            {/* ── Evidence ───────────────────────────────────────────────── */}
            <section id="evidence">
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1">05</p>
              <SectionTitle id="evidence-title">Evidencia</SectionTitle>
              <p className="mt-3 mb-5 text-sm text-muted-foreground leading-relaxed max-w-2xl">
                Cada certificado debe estar respaldado por evidencia documental verificable. Proofact almacena los archivos con hash SHA-256 para garantizar integridad a largo plazo.
              </p>
              <div className="space-y-3">
                {evidenceEndpoints.map((ep) => (
                  <EndpointCard key={ep.path + ep.method} endpoint={ep} />
                ))}
              </div>
            </section>

            <Separator />

            {/* ── Webhooks ───────────────────────────────────────────────── */}
            <section id="webhooks">
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1">06</p>
              <SectionTitle id="webhooks-title">Webhooks</SectionTitle>
              <p className="mt-3 text-sm text-muted-foreground leading-relaxed max-w-2xl">
                Registra una URL de tu servidor para recibir notificaciones en tiempo real cuando ocurran eventos relevantes en tu cuenta. Proofact firma cada payload con HMAC-SHA256.
              </p>

              <div className="mt-5 overflow-hidden rounded-xl border border-border">
                <table className="w-full text-sm">
                  <thead className="bg-muted/50">
                    <tr>
                      <th className="px-4 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">Evento</th>
                      <th className="px-4 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">Cuándo se dispara</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {webhookEvents.map((w) => (
                      <tr key={w.event} className="hover:bg-muted/20 transition-colors">
                        <td className="px-4 py-3">
                          <code className="rounded bg-muted px-1.5 py-0.5 text-xs font-mono">{w.event}</code>
                        </td>
                        <td className="px-4 py-3 text-sm text-muted-foreground">{w.desc}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <CodeBlock
                lang="typescript"
                code={`// Verificar la firma del webhook en Next.js
import crypto from 'crypto'

export async function POST(req: Request) {
  const body      = await req.text()
  const signature = req.headers.get('proofact-signature') ?? ''
  const expected  = crypto
    .createHmac('sha256', process.env.PROOFACT_WEBHOOK_SECRET!)
    .update(body)
    .digest('hex')

  if (signature !== \`sha256=\${expected}\`) {
    return new Response('Unauthorized', { status: 401 })
  }

  const event = JSON.parse(body)

  if (event.type === 'certificate.issued') {
    const { id, public_url, client_id } = event.data
    // notifica a tu cliente, actualiza tu DB, envía email...
    console.log(\`Certificado \${id} emitido para cliente \${client_id}\`)
  }

  return new Response('OK')
}`}
              />
            </section>

            <Separator />

            {/* ── Error codes ────────────────────────────────────────────── */}
            <section id="errors">
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1">07</p>
              <SectionTitle id="errors-title">Códigos de error</SectionTitle>
              <p className="mt-3 mb-5 text-sm text-muted-foreground leading-relaxed">
                La API devuelve errores en formato JSON con los campos <code className="rounded bg-muted px-1.5 py-0.5 font-mono text-xs">error.code</code> y <code className="rounded bg-muted px-1.5 py-0.5 font-mono text-xs">error.message</code>.
              </p>
              <div className="overflow-hidden rounded-xl border border-border">
                <table className="w-full text-sm">
                  <thead className="bg-muted/50">
                    <tr>
                      <th className="px-4 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">HTTP</th>
                      <th className="px-4 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">Código</th>
                      <th className="px-4 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">Descripción</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {[
                      { http: '400', code: 'invalid_params', desc: 'Faltan campos requeridos o el formato es incorrecto.' },
                      { http: '401', code: 'unauthorized', desc: 'API Key ausente, expirada o inválida.' },
                      { http: '403', code: 'forbidden', desc: 'Tu plan no tiene acceso a este recurso.' },
                      { http: '404', code: 'not_found', desc: 'El recurso solicitado no existe o fue eliminado.' },
                      { http: '409', code: 'duplicate_client', desc: 'Ya existe un cliente con ese external_id.' },
                      { http: '422', code: 'evidence_mismatch', desc: 'Los evidence_ids no pertenecen al proyecto indicado.' },
                      { http: '429', code: 'rate_limited', desc: 'Superaste el límite de solicitudes. Reintenta con backoff.' },
                      { http: '500', code: 'server_error', desc: 'Error interno. Consulta el statuspage de Proofact.' },
                    ].map((e) => (
                      <tr key={e.code} className="hover:bg-muted/20 transition-colors">
                        <td className="px-4 py-3">
                          <Badge variant="secondary" className="font-mono text-xs">{e.http}</Badge>
                        </td>
                        <td className="px-4 py-3">
                          <code className="rounded bg-muted px-1.5 py-0.5 text-xs font-mono">{e.code}</code>
                        </td>
                        <td className="px-4 py-3 text-sm text-muted-foreground">{e.desc}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>

            <Separator />

            {/* ── SDKs ───────────────────────────────────────────────────── */}
            <section id="sdks">
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1">08</p>
              <SectionTitle id="sdks-title">SDKs oficiales</SectionTitle>
              <p className="mt-3 mb-6 text-sm text-muted-foreground leading-relaxed max-w-2xl">
                Los SDKs gestionan autenticación, reintentos con backoff exponencial, validación de webhooks y TypeScript / type hints de forma automática.
              </p>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                {[
                  {
                    lang: 'Node.js / TypeScript',
                    install: 'npm install @proofact/node',
                    version: '1.4.2',
                    badge: 'bg-brand-lime-light text-[oklch(0.28_0.1_152)]',
                  },
                  {
                    lang: 'Python',
                    install: 'pip install proofact',
                    version: '1.2.0',
                    badge: 'bg-brand-blue-light text-[oklch(0.28_0.12_245)]',
                  },
                ].map((sdk) => (
                  <Card key={sdk.lang} className="flex flex-col gap-3 p-5">
                    <div className="flex items-center justify-between">
                      <p className="font-semibold text-sm text-foreground">{sdk.lang}</p>
                      <span className={cn('rounded-full px-2 py-0.5 text-xs font-mono', sdk.badge)}>
                        v{sdk.version}
                      </span>
                    </div>
                    <div className="relative rounded-lg bg-[oklch(0.18_0.03_155)] p-3">
                      <CopyButton text={sdk.install} />
                      <code className="text-xs font-mono text-[oklch(0.88_0.03_150)]">{sdk.install}</code>
                    </div>
                  </Card>
                ))}
              </div>

              {/* Final CTA */}
              <div className="mt-12 rounded-2xl bg-[oklch(0.22_0.04_155)] p-8 text-[oklch(0.95_0.01_150)]">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-brand-lime/20">
                  <Key className="h-5 w-5 text-brand-lime" />
                </div>
                <h3 className="mt-4 font-heading text-xl font-normal text-balance">
                  Listo para emitir tu primer certificado
                </h3>
                <p className="mt-2 text-sm text-[oklch(0.72_0.025_150)] leading-relaxed max-w-lg">
                  Crea tu cuenta, ve a <strong className="text-[oklch(0.88_0.02_150)]">Configuración → API Keys</strong> y genera tu primera clave de sandbox. Sin tarjeta de crédito.
                </p>
                <div className="mt-6 flex flex-wrap gap-3">
                  <Link
                    href="/register"
                    className={cn(
                      buttonVariants({ size: 'default' }),
                      'bg-brand-lime text-[oklch(0.15_0.04_155)] hover:bg-[oklch(0.66_0.17_130)] font-semibold',
                    )}
                  >
                    Crear cuenta gratis <ArrowRight className="ml-1.5 h-4 w-4" />
                  </Link>
                  <Link
                    href="/verify"
                    className={cn(
                      buttonVariants({ variant: 'outline' }),
                      'border-[oklch(0.38_0.12_152)/50] text-[oklch(0.88_0.02_150)] bg-transparent hover:bg-[oklch(0.28_0.05_155)]',
                    )}
                  >
                    Ver ejemplo de certificado
                  </Link>
                </div>
              </div>
            </section>

          </main>
        </div>
      </div>
    </div>
  )
}
